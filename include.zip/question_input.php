<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>Ela - Bootstrap Admin Dashboard Template</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:** -->
    <!--[if lt IE 9]>
    <script src="https:**oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https:**oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="fix-header fix-sidebar">
    <!-- Preloader - style you can find in spinners.css -->
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <!-- header header  -->
        <div class="header">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <div class="navbar-collapse">
                    <!-- toggle and nav items -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                    </ul>
                    <!-- User profile and search -->
                    <ul class="navbar-nav my-lg-0">
                        <!-- Profile -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="javascript:void(0);" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="images/users/5.jpg" alt="user" class="profile-pic" /></a>
                            <div class="dropdown-menu dropdown-menu-right animated zoomIn">
                                <ul class="dropdown-user">
                                    <li><a href="index.html"><i class="fa fa-power-off"></i> Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- End header header -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <!-- <div class="page-wrapper"> -->
            <!-- Bread crumb -->
            <!-- End Bread crumb -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- Start Page Content -->
                <div class="row justify-content-center" id="addelement">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-body" id="card-body">
                                <div class="form-validation">
                                    <form class="form-valide" action="javascript:void(0)" method="post">
                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">How Many question you want to add <span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <select class="form-control" id="question-number" name="questionnumber" onchange = "questions()">
                                                    <option value="">Select question numbers</option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5">5</option>
                                                    <option value="6">6</option>
                                                    <option value="7">7</option>
                                                    <option value="8">8</option>
                                                    <option value="9">9</option>
                                                    <option value="10">10</option>
                                                    <option value="11">11</option>
                                                    <option value="12">12</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row justify-content-center">
                                            <div class="col-lg-8">
                                            <input type="file" name="filename" accept="application/msexcel" />
                                            <input type="submit" name="upload" class="btn btn-primary"/>
                                            </div>
                                        </div>
                                        <table class='table table-stripped' id="table_title">  </table>
                                        <!-- <table class='table table-stripped' id="table_data">  </table> -->
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End PAge Content -->
            </div>
            <!-- End Container fluid  -->
            <!-- footer -->
            <!-- <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer> -->
            <!-- End footer -->
        <!-- </div> -->
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- javascript -->
    <script <src="js/function.js"></script>
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>


    <!-- Form validation -->
    <script src="js/lib/form-validation/jquery.validate.min.js"></script>
    <script src="js/lib/form-validation/jquery.validate-init.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>

</body>
                                <script>
                                    function questions(){
                                    var select = document.getElementById('question-number');
                                    var value = select.value;
                                            document.getElementById('table_title').innerHTML='';
                                    if (value > 0){
                                            // document.getElementById('card-body').innerHTML+="<table class='table'> <thead> <tr> <td> Question label </td> <td> Question input </td> </tr> </thead> </table>";
                                            document.getElementById('table_title').innerHTML+=" <thead> <tr> <td> Question label </td> <td> Question input </td> </tr> </thead>";
                                        for(var i=0; i < value; i++) {
                                            document.getElementById('table_title').innerHTML+="<tbody> <tr> <td> <input type='text'> </td>  <td> <input type='text' id='options' class='options'></td> </tr> </tbody>";
                                            // document.getElementById('card-body').innerHTML+="<table class='table table-stripped'> <tbody> <tr> <td> <input type='text'> </td>  <td> <input type='text' id='options'></td> <td> <button type='submit' class='btn btn-primary' onclick = 'optionsrow()'>Submit</button> </td> </tr> </tbody> </table>";
                                            }
                                        }
                                    }

                                    $('table').on('keyup','.options',function(){
                                        var optionValue=$(this).val();
                                        $(this).parent('tr').after('<tr><td><input type="text"></td><td><input type="text"></td><td><input type="text"></td><td><input type="text"></td></tr>');
                                        
                                    });
                                    // function options(){
                                    // var select = document.getElementById('options');
                                    // var value = select.value;
                                    // alert(value);}

                                    // if (value > 0){
                                    //     for(var i=0; i < value; i++) {
                                    //         document.getElementById('card-body').innerHTML+="<table class='table table-stripped'> <tbody> <tr> <td> <input type='text'> </td>  <td> <input type='text'></td> </tr> </tbody> </table>";
                                    //        }
                                    //    }
                                    // }
                                </script>
</html>