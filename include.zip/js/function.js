var select = document.getElementById('question-number');
                                    var value = select.value;

                                    var function questions(){

                                    if (value > 0){
                                        for(var i=0; i=value;i++) {
                                            documnet.write("<thead> <tr> <td> Question label </td> <td> Question input </td> </tr> </thead>");
                                        }
                                    }
                                }