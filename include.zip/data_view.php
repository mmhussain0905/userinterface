<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>Ela - Bootstrap Admin Dashboard Template</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:** -->
    <!--[if lt IE 9]>
    <script src="https:**oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https:**oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
.table-stripped{
    border:2px black solid;
}
tr{
    border:2px black solid;
}
a{
    text-decoration: none;
}
</style>
</head>

<body class="fix-header fix-sidebar">
    <!-- Preloader - style you can find in spinners.css -->
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <!-- header header  -->
        <div class="header">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <!-- Logo -->
                <!-- End Logo -->
                <div class="navbar-collapse">
                    <!-- toggle and nav items -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                    </ul>
                    <!-- User profile and search -->
                    <ul class="navbar-nav my-lg-0">
                    
                        <!-- Profile -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="images/users/5.jpg" alt="user" class="profile-pic" /></a>
                            <div class="dropdown-menu dropdown-menu-right animated zoomIn">
                                <ul class="dropdown-user">
                                    <li><a href="#"><i class="fa fa-power-off"></i> Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- End header header -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <!-- <div class="page-wrapper"> -->
            <!-- Bread crumb -->
            <!-- End Bread crumb -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- Start Page Content -->
                <div class="row justify-content-center" id="addelement">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body" id="card-body">

                            <h1 class="text-center">Data View </h1>
                            <p  style="color:black;" class="text-center">This is the data view screen as per requirment please click on button and record the response on back check </p>

                            <table class="table table-striped table-bordered">
                            <thead> 
                                <tr>
                                  <th scope="col">Sr.no</th>
                                  <th scope="col">Lot.No</th>
                                  <th scope="col">Interviewer Name</th>
                                  <th scope="col">Interviewer Id</th>
                                  <th scope="col">Center</th>
                                  <th scope="col">Date of interview</th>
                                  <th scope="col">Respondent Id</th>
                                  <th scope="col">Respondent Name</th>
                                  <th scope="col">Respondent Number</th>
                                  <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                                                        <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                                                        <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                                                        <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                                                        <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                                                        <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="answer_input.php"> <button type="button" class="btn btn-primary" value="verify"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>

                            <tr>
                                <th scope="row">26</th>
                                  <td>2144</td>
                                  <td>Shaista Shaikh</td>
                                  <td>HDD202098</td>
                                  <td>Karachi</td>
                                  <td>03-Mar-2018</td>
                                  <td>3</td>
                                  <td>Rukaiya</td>
                                  <td>33</td>
                                  <!-- <td><input type="submit" class="btn btn-primary" value="Verify"></td> -->
                                  <td>
                                  <div class="btn-group">
                                  <a href="#"> <button type="button" class="btn btn-primary" value="verify" onclick="answerinput"> Ready for Verify </button> </a>
                                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                  <span class="caret"></span>
                                  </button>
                                  <ul class="dropdown-menu" role="menu">
                                    <li> <a href="#"> NVR-1 </a> </li>
                                    <li> <a href="#"> Unsure </a> </li>
                                    <li> <a href="#"> Call Not received </a> </li>
                                    <li> <a href="#"> Switched off </a> </li>
                                    <li> <a href="#"> Refused to cooperate </a> </li>
                                    <li> <a href="#"> Number busy </a> </li>
                                    <li> <a href="#"> Respondent not available </a> </li>
                                    <li> <a href="#"> Unable to dialing </a> </li>
                                  </ul>
                                  </div>
                                  </td>
                            </tr>
                            </tbody>                            
                            </table>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- End PAge Content -->
            </div>
            <!-- End Container fluid  -->
            <!-- footer -->
            <!-- <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer> -->
            <!-- End footer -->
        <!-- </div> -->
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- javascript -->
    <script <src="js/function.js"></script>
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>


    <!-- Form validation -->
    <script src="js/lib/form-validation/jquery.validate.min.js"></script>
    <script src="js/lib/form-validation/jquery.validate-init.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>

</body>
<script>
// $("#tbUser").on('click', '.btnDelete', function () {
//     $(this).closest('tr').remove();
// });

function answerinput(){
window.open("answer_input.php","_self");
}
//        $(document).on('click', ':button', function (e) {

// var btn = $(e.target);
// btn.attr("disabled", "disabled"); // disable button

// });

</script>
</html>