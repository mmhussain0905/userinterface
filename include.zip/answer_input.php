<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>Ela - Bootstrap Admin Dashboard Template</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:** -->
    <!--[if lt IE 9]>
    <script src="https:**oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https:**oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="fix-header fix-sidebar">
    <!-- Preloader - style you can find in spinners.css -->
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <!-- header header  -->
        <div class="header">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <div class="navbar-collapse">
                    <!-- toggle and nav items -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                    </ul>
                    <!-- User profile and search -->
                    <ul class="navbar-nav my-lg-0">
                        <!-- Profile -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="images/users/5.jpg" alt="user" class="profile-pic" /></a>
                            <div class="dropdown-menu dropdown-menu-right animated zoomIn">
                                <ul class="dropdown-user">
                                    <li><a href="index.html"><i class="fa fa-power-off"></i> Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- End header header -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <!-- <div class="page-wrapper"> -->
            <!-- Bread crumb -->
            <!-- End Bread crumb -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- Start Page Content -->
                <div class="row justify-content-center" id="addelement">
                    <div class="col-lg-10">
                        <div class="card">
                            <div class="card-body" id="card-body">
                                <div class="form-validation">
                                    <form class="form-valide" action="user_thankyou_page.php" method="post">

                                    <h1 class="text-center" style="color:black;">Survey input for verification</h1>
                                    <p class="text-center" style="color:black; font-size:16px;">Pleas fill the backcheck survey carefully and make sure that you fill all the responses in it</p>
                                    <br>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">Sec </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">A</option>
                                                    <option value="EGP">B</option>
                                                    <option value="IRQ">C</option>
                                                    <option value="JQR">D</option>
                                                    <option value="KSA">E</option>
                                                </select>
                                            </div>
                                            </div>

                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">(S5) who is responsable for buying milk in your house? </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">Me</option>
                                                    <option value="EGP">My opinion regarding purchase</option>
                                                    <option value="IRQ">Others</option>
                                                </select>
                                            </div>
                                            </div>

                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">How many times a day the tea is being consumed in your house? </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">less then 2</option>
                                                    <option value="EGP">2 to 4 times</option>
                                                    <option value="IRQ">5 to 6 times</option>
                                                    <option value="IRQ">6 or more</option>
                                                </select>
                                            </div>
                                            </div>

                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">How many times a day the tea is being consumed by you? </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">less then 2</option>
                                                    <option value="EGP">2 to 4 times</option>
                                                    <option value="IRQ">5 to 6 times</option>
                                                    <option value="IRQ">6 or more</option>
                                                </select>
                                            </div>
                                            </div>

                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">Who makes the at your home? </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">Most often i use to make tea</option>
                                                    <option value="EGP">Usually i make the tea</option>
                                                    <option value="IRQ">Most of the time some one else make the tea or some time i use to be</option>
                                                    <option value="IRQ">I didn't make the tea</option>
                                                </select>
                                            </div>
                                            </div>

                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">What kind of milk is addedd in your tea at your home in last two weeks? </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">Unpack milk</option>
                                                    <option value="EGP">Branded pack milk(UHT)</option>
                                                    <option value="IRQ">Pasteurized Milk</option>
                                                    <option value="IRQ">Unbranded dry milk</option>
                                                    <option value="IRQ">Branded dry milk</option>
                                                </select>
                                            </div>
                                            </div>
                                            
                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">Most of the time what type of milk is being consumed at your home in last two weeks? </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">Unpack milk</option>
                                                    <option value="EGP">Branded pack milk(UHT)</option>
                                                    <option value="IRQ">Pasteurized Milk</option>
                                                    <option value="IRQ">unbranded dry milk</option>
                                                    <option value="IRQ">branded dry milk</option>
                                                </select>
                                            </div>
                                            </div>

                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">what kind of branded milk mostly consumed in your house? </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">Tarang</option>
                                                    <option value="EGP">CupShup</option>
                                                    <option value="IRQ">Everyday</option>
                                                    <option value="IRQ">Dost Tea</option>
                                                    <option value="IRQ">Qudrat</option>
                                                </select>
                                            </div>
                                            </div>

                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">last two weeks back what type of branded milk is consumed in your house? </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">Tarang</option>
                                                    <option value="EGP">CupShup</option>
                                                    <option value="IRQ">Everyday</option>
                                                    <option value="IRQ">Dost Tea</option>
                                                    <option value="IRQ">Qudrat</option>
                                                </select>
                                            </div>
                                            </div>

                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">what type of method is being followed to make a tea at your home? </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">Mix Tea</option>
                                                    <option value="EGP">Doodh Patti</option>
                                                    <option value="IRQ">Separate tea</option>
                                                </select>
                                            </div>
                                            </div>

                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">will you be available in next two days at your home? </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">Yes</option>
                                                    <option value="EGP">No</option>
                                                </select>
                                            </div>
                                            </div>

                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">The reason of asking this question that our representative will be visiting at your place in one or two days, and bring the sample of milk for making tea and they will provide you milk to make a tea in your kitchen and ask you about the tea to breif the samples provided to you. Are you agree to accept this activity? </label>
                                            <div class="col-lg-8">
                                                <select class="form-control" id="val-skill" name="sec">
                                                    <option value="">Please select</option>
                                                    <option value="BHR">Yes</option>
                                                    <option value="EGP">No</option>
                                                </select>
                                            </div>
                                            </div>

                                            <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-skill">Comments </label>
                                            <div class="col-lg-8">
                                            <!-- <input type="text" class="col-lg-12" rows="10"> -->
                                            <textarea name="message" id="message" cols="70" rows="5"></textarea>
                                            </div>
                                            </div>

                                            <div class="form-group row justify-content-center">
                                            <input type="submit" class="btn btn-primary" onclick="openpage()">
                                            </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End PAge Content -->
            </div>
            <!-- End Container fluid  -->
            <!-- footer -->
            <!-- <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com">Colorlib</a></footer> -->
            <!-- End footer -->
        <!-- </div> -->
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- javascript -->
    <script <src="js/function.js"></script>
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>


    <!-- Form validation -->
    <script src="js/lib/form-validation/jquery.validate.min.js"></script>
    <script src="js/lib/form-validation/jquery.validate-init.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>

</body>
<script>
function openpage(){
    window.open("user_thankyou_page.php","_self");
}
</script>
</html>